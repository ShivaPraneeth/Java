// ----------------------------------------------------- 
// Assignment A2
// Written by: (Shiva Praneeth Pabhathi, Sruthi Podupati and 2091461, 1995568) 
/*
PURPOSE:
	 The below program is used to track the information about multiple metro trains and that keeps track of stations and who gets on and off
	 In the program the user need to enter the number of trains he want to track and he can also choose the train he want to track among the 
	 number of trains.
	 The user is required to enter the number of stations and the number of stations should not be less than 3 
	 After entering the number of stations it asks the user whether he want to track the metro or not.
	 if yes it displays information about train.
	 It prompts the user again whether he want to track train.If he enters no then it asks the user whether he want to track the other trains.
	 If he enters yes then it asks the user to choose the other train.
	 finally it  asks the user whether he want to compare the trains. If yes it displays information about two trains.
 DESIGNING THE CODE:
   we used scanner to read the number of trains and random function for people boarding off and boarding on.
   we declared an array for storing the number of trains and for loop for printing the randomly generated metro ids.
   we used if condition for checking whether the number of stations are less than 3.
   startJourney is the main part of the code which initialises all the variables and consists of conditions. It consists of if statements 
   which determines which station the train is at and we used if condition for passengers not exceeding 300.
   In this method we used many if conditions regarding the no of stations and passengers
   we used equalsIgnoreCase for comparing the strings.
   We used array Index for comparing two trains.

 */
package AssignmentA2;


import java.util.Scanner;

public class Main
{
	public static void main(String[] args) {
		//Console Statements
		System.out.println("Welcome to Metro Manager- Enjoy your Metro Experience");
		System.out.println("----------------------------------------------------------------------------");
		int num_of_trains = 0;
		System.out.println("Enter the number of trains you want to track:");
		//creating Scanner with sc object which is used to access the all the methods present in sc class
		Scanner sc= new Scanner(System.in);
		//initializing num of trains to user input through sc.nextInt() method
		num_of_trains = sc.nextInt();
		Train[] tr = new Train[num_of_trains];
		//initializing number of train array
		for(int i=0;i<num_of_trains;i++){
			Train temp = new Train();
			tr[i] = temp;
		}
		int exit = 0;
		//the code gets executed once even though the condition is false 

		do{
			System.out.println("choose train you want to track");
			for(int i=0;i<num_of_trains;i++){
				System.out.println(i+". "+tr[i].metro_id);
			}
			int ch;
			ch = sc.nextInt();

			String contunue;
			int temp = 0;
			int totstations = 0;
			System.out.println("Enter number of metro stations (minimum 3):");
			totstations = sc.nextInt();
			if(totstations<3) {
				System.out.println("Woops! number of metro stations must be greater than 2");
				totstations=sc.nextInt();
			}

			else
			{
				System.out.println("----------------------------------------------");

				System.out.println("This Metro line has "+totstations+" stations");
			}
			//the below do statement is used to ask the user whether he want to track the train or not if so user need to type y or Y otherwise he can use any key
			do {
				// t.StartJourney(t.metro_id);
				//creating object t in the default constructor
				Train t = new Train();
				t = tr[ch];
				t.total_stations = totstations;
				System.out.println("Do you want to track train " +t.metro_id+" if yes type y or Y if not some other key");
				System.out.println("------------------------------------------------------------------------------------");
				//used different variable because of exception handling
				Scanner lsc= new Scanner(System.in);
				contunue = lsc.nextLine();
				
				//checks whether the given input is y or not if so the beow code get executed 
				if(contunue.equalsIgnoreCase("y")){ 
					temp = 1;
					t.StartJourney(t.metro_id);
					
				}
				//otherwise else will which will terminate the loop
				else{
					temp = 0;
				
				}

			}while (temp == 1)
				;//continues till the statement gets false

			System.out.println("Do you want to track other trains if yes enter 1 or enter any number for no");

			exit = sc.nextInt();

			System.out.println("Thank you for using Metro Manager");
			System.out.println("Be sure to look out for future enhancements");

		}while(exit == 1);// if the user want to track any other train 

		int tem=0;
		//for comparison of two trains 
		do {
			String c;
			System.out.println("Do you want to Compare metro trains  if yes type y or Y if not some other key");
			Scanner m=new Scanner(System.in);
			c = m.nextLine();
			if(c.equalsIgnoreCase("y")){ 
				System.out.println("Enter the First Train index to compare from the number of trains to track ");
				int FirstTrain=m.nextInt();
				System.out.println("Enter the Second Train index to compare from the number of trains to track ");
				int SecondTrain=m.nextInt();
				System.out.println("Comparing two trains ");
				System.out.println("Details of First Train are ");
				System.out.println("First Train metro id is "+tr[FirstTrain].metro_id);
				System.out.println("First Train total Passengers Board in "+tr[FirstTrain].passengers_boardingin);
				System.out.println("First Train number of stations "+tr[FirstTrain].total_stations);
				System.out.println("Details of Second Train are ");
				System.out.println("Second Train metro id is "+tr[SecondTrain].metro_id);
				System.out.println("Second Train total Passengers Board in "+tr[SecondTrain].passengers_boardingin);
				System.out.println("Second Train number of stations "+tr[FirstTrain].total_stations);
				System.out.println("Successfully Compared two trains");
				tem=1;
				
			}
			
		}while (tem== 1);
		System.exit(0);
	//sc.close();

	}
}


