package AssignmentA2;

import java.util.Random;
import java.util.Scanner;

public class Train {
	//variable declaration
	int metro_id,total_stations,stationNum;
	String direction= "East";
	//random function
	Random r= new Random();
	int passengers_boardingin,total_passengers=0,passengers_leftbehind=0;
	int LeavingPeople;
	//constructor with no parameters or default constructor
	public Train(){
		int max = 1000; 
		int min = 1; 
		int range = max - min + 1; 
		// generate random numbers within 1 to 1000
		for (int i = 0; i < 1000; i++) { 
			metro_id = (int)(Math.random() * range) + min;     
		}
		stationNum = 0;
	}
	//constructor with one parameter
	public Train(int id)
	{
		metro_id=id;
		stationNum=0;
		Scanner sc= new Scanner(System.in);
		direction=sc.nextLine();
		total_stations=0;
		
	}
	// A method
	public void StartJourney(int trainId){

		//if condition checks whether the stationnum is less than toatal station then implements the code in it 
		if(stationNum  < total_stations && direction == "East"){
			stationNum = stationNum  + 1;
			passengers_leftbehind = 0;
			if (stationNum  == 1){
				//Output Statements
				System.out.println("Only in");
				System.out.println("Passengers Left from last time "+passengers_leftbehind);
				Scanner sc= new Scanner(System.in);
				//Generating passengers boardingin with random class
				passengers_boardingin = r.nextInt(251);
				LeavingPeople=0;
				System.out.println("New Passengers waiting "+ passengers_boardingin );
				System.out.println("---------------------------");
				//calculating total no of passengers
				total_passengers = (total_passengers + passengers_boardingin) - LeavingPeople;
				if(total_passengers > 300){
					passengers_leftbehind = total_passengers - 300;
					passengers_boardingin = passengers_boardingin - passengers_leftbehind;
					total_passengers = total_passengers - passengers_leftbehind;
				}

				System.out.println("Metro leaving station"+stationNum +" moving towards "+direction+ " with "+total_passengers+" passengers");
				System.out.println("passenger(s) got off: "+ LeavingPeople);
				System.out.println("passenger(s) waiting to board: "+passengers_boardingin);
				System.out.println("passenger(s) left behind waiting for next train: "+passengers_leftbehind);
				System.out.println("total passengers "+total_passengers);
			//	sc.close();
				
			}
			//when if condition fails else code is implemented
			else{
				if(stationNum  == total_stations){
					System.out.println("All out ");
					System.out.println("---------------------");
					System.out.println("last station "+stationNum +" moving towards "+direction);
					LeavingPeople = total_passengers;
					passengers_boardingin = 0;
					total_passengers = (total_passengers + passengers_boardingin) -  LeavingPeople;

					System.out.println("total passengers "+total_passengers);
					System.out.println("passenger(s) got off: "+ LeavingPeople);
					System.out.println("passenger(s) boarding in: "+passengers_boardingin);
					System.out.println("passenger(s) left behind waiting for next train: "+passengers_leftbehind);
					LeavingPeople = 0;
					direction = "west";
				
				}else{
					System.out.println("---------------------");
					System.out.println("In the Middle");
					System.out.println("current station "+stationNum +" moving towards "+direction);
					System.out.println("Enter number passengers boarding in");

					passengers_boardingin = r.nextInt(251);

					LeavingPeople=r.nextInt(passengers_boardingin+1);

					total_passengers = (total_passengers + passengers_boardingin) -  LeavingPeople;
					if(total_passengers > 300){
						passengers_leftbehind = total_passengers - 300;
						passengers_boardingin = passengers_boardingin - passengers_leftbehind;
						total_passengers = total_passengers - passengers_leftbehind;
					}
					System.out.println("total passengers "+total_passengers);
					System.out.println("passenger(s) got off: "+LeavingPeople);
					System.out.println("passenger(s) boarding in: "+passengers_boardingin);
					System.out.println("passenger(s) left behind waiting for next train: "+passengers_leftbehind);

				}
			}

		}  //when the number of stations are done the train turn around and changes the direction to west
		else if (stationNum  < total_stations && direction == "west"){
			//now the train  is in west direction and passengers are ready to board once again
			passengers_leftbehind = 0;
			if(stationNum  == 1){
				System.out.println("All out");
				System.out.println("last station "+stationNum +" moving towards "+direction);
				LeavingPeople = total_passengers;
				passengers_boardingin = 0;
				total_passengers = (total_passengers + passengers_boardingin) -  LeavingPeople;;
				System.out.println("total passengers "+total_passengers);
				System.out.println("passenger(s) got off: "+ LeavingPeople);
				System.out.println("passenger(s) waiting to board: "+passengers_boardingin);
				System.out.println("passenger(s) left behind waiting for next train: "+passengers_leftbehind);
				LeavingPeople = 0;
				stationNum  = stationNum  - 1;
				direction = "East";
			}else{
				System.out.println("In the middle");
				System.out.println("current station "+stationNum +" moving towards "+direction);
				System.out.println("Enter number passengers boarding in");

				passengers_boardingin = r.nextInt(251);

				LeavingPeople=r.nextInt(passengers_boardingin+1);
				total_passengers = (total_passengers + passengers_boardingin) -  LeavingPeople;
				if(total_passengers > 300){
					passengers_leftbehind = total_passengers - 300;
					passengers_boardingin = passengers_boardingin - passengers_leftbehind;
					total_passengers = total_passengers - passengers_leftbehind;
				}
				System.out.println("total passengers "+total_passengers);
				System.out.println("passenger(s) got off: "+LeavingPeople);
				System.out.println("passenger(s) boarding in: "+passengers_boardingin);
				System.out.println("passenger(s) left behind waiting for next train: "+passengers_leftbehind);
				stationNum  = stationNum  - 1;

			}
		}else  if (stationNum  == total_stations && direction == "west"){
			passengers_leftbehind = 0;
			System.out.println("Only in");
			System.out.println("first station "+stationNum +" moving towards "+direction);
			System.out.println("Enter number passengers boarding in");
			LeavingPeople=0;
			passengers_boardingin = r.nextInt(251);
			total_passengers = (total_passengers + passengers_boardingin) -  LeavingPeople;
			if(total_passengers > 300){
				passengers_leftbehind = total_passengers - 300;
				passengers_boardingin = passengers_boardingin - passengers_leftbehind;
				total_passengers = total_passengers - passengers_leftbehind;
			}
			System.out.println("total passengers "+total_passengers);
			System.out.println("passenger(s) got off: "+LeavingPeople);
			System.out.println("passenger(s) boarding in: "+passengers_boardingin);
			System.out.println("passenger(s) left behind waiting for next train: "+passengers_leftbehind);
			stationNum  = stationNum  - 1;
		
		}
	}
	//Accessor methods
	public int getmetro_id()
	{
		return metro_id;
	}

	public int getstationNum() {
		return stationNum;
	}

	public String getdirection() {
		return direction;
	}

	public int getpassTotal()
	{
		return total_stations;
	}

	//Mutator methods
	public void setmetro_id(int id)
	{
		metro_id= id ;
	} 
}





